globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/2c47484272abc789.js",
    "static/chunks/dce1ee0e89ee93db.js",
    "static/chunks/a0e9039376638b5f.js",
    "static/chunks/e4f73816b6086d5c.js",
    "static/chunks/turbopack-4189772a30603cb6.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];