module.exports=[24087,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_domains_page_actions_3234a29e.js.map